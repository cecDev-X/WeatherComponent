package com.weatherComponent;

import java.beans.BeanDescriptor;
import java.beans.IntrospectionException;
import java.beans.PropertyDescriptor;
import java.beans.SimpleBeanInfo;

/**
 * Metadata para el editor visual de NetBeans.
 * Esta clase proporciona información sobre las propiedades del componente
 * {@link WeatherComponent} para que puedan ser editadas visualmente en NetBeans.
 */
public class WeatherComponentBeanInfo extends SimpleBeanInfo {

    /**
     * Obtiene los descriptores de las propiedades del componente {@link WeatherComponent}.
     * Cada propiedad se asocia con un nombre, descripción y un nombre para ser mostrado
     * en el editor visual de NetBeans.
     *
     * @return Un array de descriptores de propiedades.
     */
    @Override
    public PropertyDescriptor[] getPropertyDescriptors() {
        try {
            return new PropertyDescriptor[] {
                createProperty("city", "Ciudad", "Nombre de la ciudad para mostrar"),
                createProperty("temperature", "Temperatura (C)", "Temperatura actual"),
                createProperty("showFahrenheit", "Mostrar Fahrenheit", "Muestra temperatura en Fahrenheit"),
                createProperty("backgroundColor1", "Color Fondo 1", "Primer color del gradiente"),
                createProperty("backgroundColor2", "Color Fondo 2", "Segundo color del gradiente"),
                createProperty("textColor", "Color Texto", "Color del texto"),
                createProperty("weatherCondition", "Condición", "Condición climática"),
                createProperty("apiKey", "API Key", "Clave para WeatherAPI")
            };
        } catch (IntrospectionException e) {
            return null;
        }
    }

    /**
     * Crea un descriptor de propiedad para ser usado en el editor visual de NetBeans.
     * 
     * @param name El nombre de la propiedad.
     * @param displayName El nombre que será mostrado en el editor.
     * @param description Descripción de la propiedad.
     * @return Un descriptor de propiedad.
     * @throws IntrospectionException Si ocurre un error al crear el descriptor.
     */
    private PropertyDescriptor createProperty(String name, String displayName, String description)
        throws IntrospectionException {
        PropertyDescriptor pd = new PropertyDescriptor(name, WeatherComponent.class);
        pd.setDisplayName(displayName);
        pd.setShortDescription(description);
        return pd;
    }

    /**
     * Obtiene el descriptor del bean {@link WeatherComponent}.
     * Este descriptor proporciona información general sobre el componente,
     * como su nombre y su descripción.
     *
     * @return El descriptor del bean.
     */
    @Override
    public BeanDescriptor getBeanDescriptor() {
        BeanDescriptor bd = new BeanDescriptor(WeatherComponent.class);
        bd.setDisplayName("Componente del Clima");
        bd.setShortDescription("Muestra información meteorológica actual");
        return bd;
    }
}
