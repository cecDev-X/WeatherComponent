package com.weatherComponent;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import org.json.JSONObject;

/**
 * Componente personalizado de Java Swing para mostrar la información del clima.
 * Muestra la ciudad, temperatura, condición climática y un indicador de carga.
 */
public class WeatherComponent extends JPanel {

    private String apiKey = "d2416f5bb6b244d59ee203645250305";
    private double tempC = 0;
    private String city = "Ciudad";
    private Color backgroundColor1 = new Color(100, 150, 255);
    private Color backgroundColor2 = new Color(50, 100, 200);
    private Color textColor = Color.WHITE;
    private String weatherCondition = "Cargando...";
    private boolean showFahrenheit = false;
    private boolean loading = true;
    private boolean initialized = false;
    private boolean hasNetwork = true;

    /**
     * Constructor del componente que establece el tamaño preferido y verifica la conexión de red.
     */
    public WeatherComponent() {
        setPreferredSize(new Dimension(250, 180));
        checkNetwork();
        setupComponentListeners();

        // Forzar actualización al agregar desde NetBeans o desde un JAR
        SwingUtilities.invokeLater(() -> {
            if (!initialized && hasNetwork) {
                initialized = true;
                actualizarClima();
            }
        });
    }

    /**
     * Verifica si hay conexión de red disponible.
     */
    private void checkNetwork() {
        new Thread(() -> {
            try {
                URL url = new URL("http://clients3.google.com/generate_204");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setConnectTimeout(5000);
                conn.connect();
                hasNetwork = true;
            } catch (Exception e) {
                hasNetwork = false;
                SwingUtilities.invokeLater(() -> {
                    weatherCondition = "Sin conexión";
                    loading = false;
                    repaint();
                });
            }
        }).start();
    }

    /**
     * Establece los oyentes de eventos para el componente, como el evento de redimensionado y mostrado.
     */
    private void setupComponentListeners() {
        addComponentListener(new ComponentAdapter() {
            @Override
            public void componentShown(ComponentEvent e) {
                if (!initialized && hasNetwork) {
                    initialized = true;
                    actualizarClima();
                }
            }

            @Override
            public void componentResized(ComponentEvent e) {
                if (!initialized && hasNetwork) {
                    initialized = true;
                    actualizarClima();
                }
            }
        });
    }

    /**
     * Dibuja el componente de clima, incluidos el fondo, los íconos, la temperatura y el estado del clima.
     *
     * @param g El objeto Graphics que se utiliza para dibujar.
     */
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        GradientPaint gradient = new GradientPaint(0, 0, backgroundColor1, getWidth(), getHeight(), backgroundColor2);
        g2d.setPaint(gradient);
        g2d.fillRect(0, 0, getWidth(), getHeight());

        drawWeatherIcon(g2d);
        drawCityName(g2d);
        drawTemperature(g2d);
        drawWeatherCondition(g2d);

        if (loading && hasNetwork) {
            drawLoadingIndicator(g2d);
        }
    }

    /**
     * Dibuja el nombre de la ciudad en el componente.
     *
     * @param g2d El objeto Graphics2D que se utiliza para dibujar.
     */
    private void drawCityName(Graphics2D g2d) {
        g2d.setColor(textColor);
        g2d.setFont(new Font("Arial", Font.BOLD, 18));
        g2d.drawString(city, 25, 30);
    }

    /**
     * Dibuja la temperatura en grados Celsius o Fahrenheit según la configuración.
     *
     * @param g2d El objeto Graphics2D que se utiliza para dibujar.
     */
    private void drawTemperature(Graphics2D g2d) {
        g2d.setFont(new Font("Arial", Font.BOLD, 42));
        String tempText = showFahrenheit 
            ? String.format("%.1f °F", (tempC * 9 / 5) + 32)
            : String.format("%.1f °C", tempC);
        g2d.drawString(tempText, 25, 90);
    }

    /**
     * Dibuja el estado del clima en el componente.
     *
     * @param g2d El objeto Graphics2D que se utiliza para dibujar.
     */
    private void drawWeatherCondition(Graphics2D g2d) {
        g2d.setFont(new Font("Arial", Font.PLAIN, 16));
        g2d.drawString(weatherCondition, 25, 120);
    }

    /**
     * Dibuja un indicador de carga si el componente está esperando datos.
     *
     * @param g2d El objeto Graphics2D que se utiliza para dibujar.
     */
    private void drawLoadingIndicator(Graphics2D g2d) {
        g2d.setFont(new Font("Arial", Font.ITALIC, 12));
        g2d.drawString("Actualizando...", 25, 150);
    }

    /**
     * Dibuja un ícono que representa el clima actual, como un sol o nubes.
     *
     * @param g2d El objeto Graphics2D que se utiliza para dibujar.
     */
    private void drawWeatherIcon(Graphics2D g2d) {
        g2d.setColor(new Color(255, 255, 255, 180));
        String cond = weatherCondition.toLowerCase();

        if (cond.contains("sol") || cond.contains("despej")) {
            drawSunIcon(g2d);
        } else if (cond.contains("nubl")) {
            drawCloudIcon(g2d);
        } else if (cond.contains("error") || cond.contains("sin conexión")) {
            drawErrorIcon(g2d);
        }
    }

    /**
     * Dibuja un ícono de sol en el componente.
     *
     * @param g2d El objeto Graphics2D que se utiliza para dibujar.
     */
    private void drawSunIcon(Graphics2D g2d) {
        g2d.fillOval(getWidth() - 60, 30, 40, 40);
        for (int i = 0; i < 8; i++) {
            double angle = Math.PI * i / 4;
            int x1 = getWidth() - 40 + (int)(25 * Math.cos(angle));
            int y1 = 50 + (int)(25 * Math.sin(angle));
            int x2 = getWidth() - 40 + (int)(40 * Math.cos(angle));
            int y2 = 50 + (int)(40 * Math.sin(angle));
            g2d.drawLine(x1, y1, x2, y2);
        }
    }

    /**
     * Dibuja un ícono de nubes en el componente.
     *
     * @param g2d El objeto Graphics2D que se utiliza para dibujar.
     */
    private void drawCloudIcon(Graphics2D g2d) {
        g2d.fillOval(getWidth() - 70, 35, 30, 20);
        g2d.fillOval(getWidth() - 50, 30, 40, 25);
        g2d.fillOval(getWidth() - 30, 35, 30, 20);
    }

    /**
     * Dibuja un ícono de error (cruz roja) cuando ocurre un error de conexión o en la API.
     *
     * @param g2d El objeto Graphics2D que se utiliza para dibujar.
     */
    private void drawErrorIcon(Graphics2D g2d) {
        g2d.setColor(Color.RED);
        g2d.drawLine(getWidth() - 40, 30, getWidth() - 20, 50);
        g2d.drawLine(getWidth() - 20, 30, getWidth() - 40, 50);
        g2d.drawOval(getWidth() - 45, 25, 30, 30);
    }

    /**
     * Actualiza la información del clima desde la API.
     */
    public void actualizarClima() {
        if (!hasNetwork) {
            weatherCondition = "Sin conexión";
            loading = false;
            repaint();
            return;
        }

        loading = true;
        repaint();

        new Thread(() -> {
            try {
                System.setProperty("java.net.preferIPv4Stack", "true");
                String urlStr = "http://api.weatherapi.com/v1/current.json?key=" + apiKey 
                             + "&q=" + city + "&lang=es";

                URL url = new URL(urlStr);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");
                conn.setConnectTimeout(8000);
                conn.setReadTimeout(8000);

                if (conn.getResponseCode() == 200) {
                    BufferedReader in = new BufferedReader(
                        new InputStreamReader(conn.getInputStream()));
                    StringBuilder response = new StringBuilder();
                    String inputLine;

                    while ((inputLine = in.readLine()) != null) {
                        response.append(inputLine);
                    }
                    in.close();

                    JSONObject jsonResponse = new JSONObject(response.toString());
                    JSONObject current = jsonResponse.getJSONObject("current");

                    final double nuevaTemp = current.getDouble("temp_c");
                    final String nuevaCondicion = (nuevaTemp < 20) ? "Nublado" : "Soleado";

                    SwingUtilities.invokeLater(() -> {
                        this.tempC = nuevaTemp;
                        this.weatherCondition = nuevaCondicion;
                        this.loading = false;
                        repaint();
                    });
                } else {
                    SwingUtilities.invokeLater(() -> {
                        this.weatherCondition = "Error en API";
                        this.loading = false;
                        repaint();
                    });
                }
            } catch (Exception e) {
                SwingUtilities.invokeLater(() -> {
                    this.weatherCondition = "Error de conexión";
                    this.loading = false;
                    repaint();
                });
            }
        }).start();
    }

    // Getters y Setters públicos para configurar el componente desde NetBeans

    /**
     * Obtiene el nombre de la ciudad.
     * 
     * @return El nombre de la ciudad.
     */
    public String getCity() {
        return city;
    }

    /**
     * Establece el nombre de la ciudad y actualiza el clima.
     *
     * @param city El nombre de la ciudad.
     */
    public void setCity(String city) {
        if (city != null && !city.trim().isEmpty() && !city.equals(this.city)) {
            this.city = city;
            actualizarClima();
        }
    }

    /**
     * Obtiene la temperatura actual en grados Celsius.
     * 
     * @return La temperatura en grados Celsius.
     */
    public double getTemperature() {
        return tempC;
    }

    /**
     * Establece la temperatura actual y actualiza el componente.
     *
     * @param tempC La temperatura en grados Celsius.
     */
    public void setTemperature(double tempC) {
        this.tempC = tempC;
        repaint();
    }

    /**
     * Verifica si la temperatura se debe mostrar en Fahrenheit.
     * 
     * @return true si la temperatura se debe mostrar en Fahrenheit, false en Celsius.
     */
    public boolean isShowFahrenheit() {
        return showFahrenheit;
    }

    /**
     * Establece si la temperatura debe mostrarse en Fahrenheit.
     *
     * @param showFahrenheit true para mostrar en Fahrenheit, false en Celsius.
     */
    public void setShowFahrenheit(boolean showFahrenheit) {
        this.showFahrenheit = showFahrenheit;
        repaint();
    }

    /**
     * Obtiene el color de fondo 1 del componente.
     * 
     * @return El color de fondo 1.
     */
    public Color getBackgroundColor1() {
        return backgroundColor1;
    }

    /**
     * Establece el color de fondo 1 del componente.
     *
     * @param backgroundColor1 El color de fondo 1.
     */
    public void setBackgroundColor1(Color backgroundColor1) {
        this.backgroundColor1 = backgroundColor1;
        repaint();
    }

    /**
     * Obtiene el color de fondo 2 del componente.
     * 
     * @return El color de fondo 2.
     */
    public Color getBackgroundColor2() {
        return backgroundColor2;
    }

    /**
     * Establece el color de fondo 2 del componente.
     *
     * @param backgroundColor2 El color de fondo 2.
     */
    public void setBackgroundColor2(Color backgroundColor2) {
        this.backgroundColor2 = backgroundColor2;
        repaint();
    }

    /**
     * Obtiene el color del texto del componente.
     * 
     * @return El color del texto.
     */
    public Color getTextColor() {
        return textColor;
    }

    /**
     * Establece el color del texto del componente.
     *
     * @param textColor El color del texto.
     */
    public void setTextColor(Color textColor) {
        this.textColor = textColor;
        repaint();
    }

    /**
     * Obtiene el estado actual del clima.
     * 
     * @return El estado del clima.
     */
    public String getWeatherCondition() {
        return weatherCondition;
    }

    /**
     * Verifica si el componente está en proceso de carga de información.
     * 
     * @return true si está cargando, false si ya ha cargado la información.
     */
    public boolean isLoading() {
        return loading;
    }

    /**
     * Crea un componente de paleta visual para el componente de clima.
     *
     * @return Un nuevo componente WeatherComponent.
     */
    public java.awt.Component createPaletteComponent() {
        return new WeatherComponent();
    }
}
